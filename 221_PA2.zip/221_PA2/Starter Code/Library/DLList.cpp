// implementation of the DLList class

#include "DLList.h"
#include <exception>

struct EmptyLinkedListException : public std::exception {
    const char * what () const throw ()
    {
        return "C++ Exception";
    }
};




// Default Constructor
DLList::DLList() {
    header = 0;
    trailer = 0;
    header.next = &trailer;
    trailer.prev = &header;
}

// Copy Constructor
DLList::DLList(const DLList& dll) {
    header = 0;
    trailer = 0;
    header.next = &trailer;
    trailer.prev = &header;
    DLListNode* temp = dll.header.next;
    while(temp != &dll.trailer){
        this->insert_last(temp->obj);
        temp = temp->next;
    }
    
}

// Move Constructor
DLList::DLList(DLList&& dll) {
    header = dll.header;
    dll.header.next->prev = &header;
    trailer = dll.trailer;
    dll.trailer.prev->next = &trailer;
    dll.header = 0;
    dll.trailer = 0;
    dll.header.next = &dll.trailer;
    dll.trailer.prev = &dll.header;
}

// Destructor
DLList::~DLList(){
    DLListNode* prevNode,* currNode = header.next;
    while (currNode != &trailer) {
        prevNode = currNode;
        currNode = currNode->next;
        delete prevNode;
    }
    header.next = &trailer;
    trailer.prev = &header;
}

// Copy Assignment Operator
DLList& DLList::operator=(const DLList& dll) {
    if (this != &dll) {
        if (!this->is_empty()) {
            DLListNode* prevNode,* currNode = header.next;
            while (currNode != &trailer) {
                prevNode = currNode;
                currNode = currNode->next;
                delete prevNode;
            }
            header.next = &trailer;
            trailer.prev = &header;
        }
        header = 0;
        trailer = 0;
        header.next = &trailer;
        trailer.prev = &header;
        DLListNode* temp = dll.header.next;
        while(temp != &dll.trailer){
            this->insert_last(temp->obj);
            temp = temp->next;
        }
        
    }
    return *this;
}

// Move Assignment Operator
DLList& DLList::operator=(DLList&& dll) {
    if (!this->is_empty()) {
        DLListNode* prevNode,* currNode = header.next;
        while (currNode != &trailer) {
            prevNode = currNode;
            currNode = currNode->next;
            delete prevNode;
        }
        header.next = &trailer;
        trailer.prev = &header;
    }
    header = dll.header;
    dll.header.next->prev = &header;
    trailer = dll.trailer;
    dll.trailer.prev->next = &trailer;
    dll.header = 0;
    dll.trailer = 0;
    dll.header.next = &dll.trailer;
    dll.trailer.prev = &dll.header;
    return *this;
}

// First Node Function
DLListNode *DLList::first_node() const {
    return header.next;
}

// After Last Node Function
const DLListNode *DLList::after_last_node() const {
    return &trailer;
}

// Is Empty Function
bool DLList::is_empty() const {
    if (header.next == &trailer) {
        return true;
    } else {
        return false;
    }
}

// First Function
int DLList::first() const {
    if (this->is_empty()) {
        throw EmptyLinkedListException();
    }
    return header.next->obj;
}

// Last Function
int DLList::last() const {
    if (this->is_empty()) {
        throw EmptyLinkedListException();
    }
    return trailer.prev->obj;
}

// Insert First Function
void DLList::insert_first(int obj) {
    DLListNode* newNode = new DLListNode(obj, &header, header.next);
    header.next->prev = newNode;
    header.next = newNode;
}

// Remove First Function
int DLList::remove_first() {
    if (this->is_empty()) {
        throw EmptyLinkedListException();
    }
    DLListNode* tempNode = header.next;
    tempNode->next->prev = &header;
    header.next = tempNode->next;
    int obj = tempNode->obj;
    delete tempNode;
    return obj;
}

// Insert Last Function
void DLList::insert_last(int obj) {
    DLListNode* newNode = new DLListNode(obj, trailer.prev, &trailer);
    trailer.prev->next = newNode;
    trailer.prev = newNode;
}

// Remove Last Function
int DLList::remove_last() {
    if (this->is_empty()) {
        throw EmptyLinkedListException();
    }
    DLListNode* tempNode = trailer.prev;
    tempNode->prev->next = &trailer;
    trailer.prev = tempNode->prev;
    int obj = tempNode->obj;
    delete tempNode;
    return obj;
}

// Insert After Function
void DLList::insert_after(DLListNode &p, int obj) {
    DLListNode* newNode = new DLListNode(obj, &p, p.next);
    //DLListNode* temp = header.next;
    //while(temp != &p){
    //    temp = temp->next;
    //}
    p.next = newNode;
    newNode->prev = &p;
    newNode->next->prev = newNode;
}

// Insert Before Function
void DLList::insert_before(DLListNode &p, int obj) {
    DLListNode* newNode = new DLListNode(obj, p.prev, &p);
    // DLListNode* temp = header.next;
    // while(temp != &p){
    //     temp = temp->next;
    // }
    p.prev->next = newNode;
    p.prev = newNode;
}

// Remove After Function
int DLList::remove_after(DLListNode &p) {
    if (this->is_empty() || &p == trailer.prev) {
        throw EmptyLinkedListException();
    }
    // DLListNode* temp = header.next;
    // while(temp != &p){
    //     temp = temp->next;
    // }
    int obj = p.next->obj;
    DLListNode* deleteNode = p.next;
    deleteNode->next->prev = &p;
    p.next = deleteNode->next;
    delete deleteNode;
    return obj;
}

// Remove Before Function
int DLList::remove_before(DLListNode &p) {
    if (this->is_empty() || &p == header.next) {
        throw EmptyLinkedListException();
    }
    // DLListNode* temp = header.next;
    // while(temp != &p){
    //     temp = temp->next;
    // }
    int obj = p.prev->obj;
    DLListNode* deleteNode = p.prev;
    deleteNode->prev->next = &p;
    p.prev = deleteNode->prev;
    delete deleteNode;
    return obj;
}

ostream& operator<<(ostream& out, const DLList& dll) {
    DLListNode* temp = dll.first_node();
    while(temp != dll.after_last_node()) {
        out << temp->obj << ", ";
        temp = temp->next;
    }
    return out;
}