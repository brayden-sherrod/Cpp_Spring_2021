// header file for the templated DLList

#ifndef TEMPLATEDDLLIST_H
#define TEMPLATEDDLLIST_H

#include <iostream>
#include <stdexcept>

using namespace std;

struct EmptyLinkedListException : public std::exception {
    const char * what () const throw ()
    {
        return "C++ Exception";
    }
};

template <typename T>
class DLList; // class declaration

// doubly linked list node
template <typename T>
struct DLListNode {
  T obj;
  DLListNode<T> *prev, *next;
  // constructor
  DLListNode(T e=T(), DLListNode *p=nullptr, DLListNode *n=nullptr): obj(e), prev(p), next(n) {}
};

// doubly linked list class
template <typename T>
class DLList {
private:
  DLListNode<T> header, trailer;
public:
  DLList() {
    header = T();
    trailer = T();
    header.next = &trailer;
    trailer.prev = &header;
  }// default constructor
  DLList(const DLList<T>& dll) {
    header = T();
    trailer = T();
    header.next = &trailer;
    trailer.prev = &header;
    DLListNode<T>* temp = dll.header.next;
    while(temp != &dll.trailer){
        this->insert_last(temp->obj);
        temp = temp->next;
    }
    
  } // copy constructor

  DLList(DLList<T>&& dll) {
    header = dll.header;
    dll.header.next->prev = &header;
    trailer = dll.trailer;
    dll.trailer.prev->next = &trailer;
    dll.header = T();
    dll.trailer = T();
    dll.header.next = &dll.trailer;
    dll.trailer.prev = &dll.header;
  } // move constructor

  ~DLList() {
    DLListNode<T>* prevNode,* currNode = header.next;
    while (currNode != &trailer) {
        prevNode = currNode;
        currNode = currNode->next;
        delete prevNode;
    }
    header.next = &trailer;
    trailer.prev = &header;
  } // destructor

  DLList<T>& operator=(const DLList<T>& dll) {
    if (this != &dll) {
      if (!this->is_empty()) {
          DLListNode<T>* prevNode,* currNode = header.next;
          while (currNode != &trailer) {
              prevNode = currNode;
              currNode = currNode->next;
              delete prevNode;
          }
          header.next = &trailer;
          trailer.prev = &header;
      }
      header = T();
      trailer = T();
      header.next = &trailer;
      trailer.prev = &header;
      DLListNode<T>* temp = dll.header.next;
      while(temp != &dll.trailer){
          this->insert_last(temp->obj);
          temp = temp->next;
      }
        
    }
    return *this;
  } // copy assignment operator
  DLList<T>& operator=(DLList<T>&& dll) {
    if (!this->is_empty()) {
          DLListNode<T>* prevNode,* currNode = header.next;
          while (currNode != &trailer) {
              prevNode = currNode;
              currNode = currNode->next;
              delete prevNode;
          }
          header.next = &trailer;
          trailer.prev = &header;
      }
    header = dll.header;
    dll.header.next->prev = &header;
    trailer = dll.trailer;
    dll.trailer.prev->next = &trailer;
    dll.header = T();
    dll.trailer = T();
    dll.header.next = &dll.trailer;
    dll.trailer.prev = &dll.header;
    return *this;
  } // move assignment operator
  // return the poTer to the first node
  DLListNode<T> *first_node() const { return header.next; } 
  // return the poTer to the trailer
  const DLListNode<T> *after_last_node() const { return &trailer; }
  // return if the list is empty
  bool is_empty() const { return header.next == &trailer; }
  T first() const {
    if (is_empty()) {
        throw EmptyLinkedListException();
    }
    return header.next->obj;
  } // return the first object

  T last() const {
    if (is_empty()) {
        throw EmptyLinkedListException();
    }
    return trailer.prev->obj;
  } // return the last object
  void insert_first(T obj) {
    DLListNode<T>* newNode = new DLListNode<T>(obj, &header, header.next);
    header.next->prev = newNode;
    header.next = newNode;
  } // insert to the first node

  T remove_first() {
    if (is_empty()) {
        throw EmptyLinkedListException();
    }
    DLListNode<T>* tempNode = header.next;
    tempNode->next->prev = &header;
    header.next = tempNode->next;
    T obj = tempNode->obj;
    delete tempNode;
    return obj;
  } // remove the first node

  void insert_last(T obj) {
    DLListNode<T>* newNode = new DLListNode<T>(obj, trailer.prev, &trailer);
    trailer.prev->next = newNode;
    trailer.prev = newNode;
  } 
  // insert to the last node

  T remove_last() {
    if (is_empty()) {
        throw EmptyLinkedListException();
    }
    DLListNode<T>* tempNode = trailer.prev;
    tempNode->prev->next = &trailer;
    trailer.prev = tempNode->prev;
    T obj = tempNode->obj;
    delete tempNode;
    return obj;
  } // remove the last node

  void insert_after(DLListNode<T> &p, T obj) {
    DLListNode<T>* newNode = new DLListNode<T>(obj, &p, p.next);
    DLListNode<T>* temp = header.next;
    while(temp != &p){
        temp = temp->next;
    }
    p.next = newNode;
    newNode->prev = &p;
    newNode->next->prev = newNode;
  }
  void insert_before(DLListNode<T> &p, T obj) {
    DLListNode<T>* newNode = new DLListNode<T>(obj, p.prev, &p);
    DLListNode<T>* temp = header.next;
    while(temp != &p){
        temp = temp->next;
    }
    p.prev->next = newNode;
    p.prev = newNode;
  }
  T remove_after(DLListNode<T> &p) {
    if (is_empty() || &p == trailer.prev) {
        throw EmptyLinkedListException();
    }
    DLListNode<T>* temp = header.next;
    while(temp != &p){
        temp = temp->next;
    }
    T obj = p.next->obj;
    p.next->next->prev = &p;
    DLListNode<T>* deleteNode = p.next;
    p.next = deleteNode->next;
    delete deleteNode;
    return obj;
  }
  T remove_before(DLListNode<T> &p) {
    if (is_empty() || &p == header.next) {
        throw EmptyLinkedListException();
    }
    DLListNode<T>* temp = header.next;
    while(temp != &p){
        temp = temp->next;
    }
    T obj = p.prev->obj;
    p.prev->prev->next = &p;
    DLListNode<T>* deleteNode = p.prev;
    p.prev = p.prev->prev;
    delete deleteNode;
    return obj;
  }
};

// output operator
template <typename T>
ostream& operator<<(ostream& out, const DLList<T>& dll) {
    DLListNode<T>* temp = dll.first_node();
    while(temp != dll.after_last_node()) {
        out << temp->obj << ", ";
        temp = temp->next;
    }
    return out;
}


#endif
