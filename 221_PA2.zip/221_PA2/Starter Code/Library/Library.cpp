#include "Library.h"
#include "TemplatedDLList.h"
#include <fstream>

// search function
std::vector<Record> Library::search(std::string title) {
    vector<Record> matches;
    int sortLetter = title[0] - 65;
    DLList<Record> dll = book_db[sortLetter];
    if (dll.is_empty()) {
        return matches;
    } else {
        DLListNode<Record>* temp = dll.first_node();
        while(temp != dll.after_last_node()) {
            if (temp->obj.get_title() == title) {
                matches.push_back(temp->obj);
            }
            temp = temp->next;  
        }
        return matches;
    }
}

// imports records from a file returns number of records
int Library::import_database(std::string filename) {
    int count = 0;
    bool successful;
    ifstream inf;
    inf.open(filename);
    Record rec;
    while (inf >> rec) {
        successful = this->add_record(rec);
        if (successful) {
            count++;
        }
    }
    inf.close();
    return count;
}

// exports records to a file returns number of records
int Library::export_database(std::string filename) {
    int count = 0;
    ofstream of;
    of.open(filename);
    for (int i = 0; i < 26; i++) {
        DLList<Record> dll = book_db[i];
        DLListNode<Record>* temp = dll.first_node();
        while(temp != dll.after_last_node()) {
            of << temp->obj.get_title() << endl;
            of << temp->obj.get_author() << endl;
            of << temp->obj.get_ISBN() << endl;
            of << temp->obj.get_year() << endl;
            of << temp->obj.get_edition() << endl;
            of << endl;
            temp = temp->next;
            count++;
        }
    }
    of.close();
    return count;
}

// prints out the whole database
void Library::print_database() {
    for (int i = 0; i < 26; i++) {
        DLList<Record> dll = book_db[i];
        DLListNode<Record>* temp = dll.first_node();
        while(temp != dll.after_last_node()) {
            cout << temp->obj.get_title() << endl;
            cout << temp->obj.get_author() << endl;
            cout << temp->obj.get_ISBN() << endl;
            cout << temp->obj.get_year() << endl;
            cout << temp->obj.get_edition() << endl;
            temp = temp->next;
        }
    }
}

// adds record to database if not complete duplicate
bool Library::add_record(Record book) {
    string title = book.get_title();
    int sortLetter = title[0] - 65;
    if (book_db[sortLetter].is_empty()) {
        book_db[sortLetter].insert_last(book);
        return true;
    }
    DLListNode<Record>* temp = book_db[sortLetter].first_node();
    string author = book.get_author();
    string ISBN = book.get_ISBN();
    while(temp != book_db[sortLetter].after_last_node()) {
        string tempTitle = temp->obj.get_title();
        string tempAuthor = temp->obj.get_author();
        string tempISBN = temp->obj.get_ISBN();
        if (tempTitle == title) {
            if (tempAuthor == author) {
                if (tempISBN == ISBN) {
                    return false;
                } else if (tempISBN > ISBN) { 
                    book_db[sortLetter].insert_before(*temp, book);
                    return true;
                }
            } else if (tempAuthor > author) { 
                book_db[sortLetter].insert_before(*temp, book);
                return true;
            }
        } else if (tempTitle > title) { 
            book_db[sortLetter].insert_before(*temp, book);
            return true;
        }
        temp = temp->next;
    }
    book_db[sortLetter].insert_last(book);
    return true;
}

// deletes record from database
void Library::remove_record(Record book) {
    string title = book.get_title();
    int sortIndex = title[0] - 65;
    DLListNode<Record>* temp = book_db[sortIndex].first_node();
    while(temp != book_db[sortIndex].after_last_node()) {
        if (temp->obj == book) {
            Record deleteRecord = book_db[sortIndex].remove_before(*temp->next);
            deleteRecord.set_title("");
            deleteRecord.set_author("");
            deleteRecord.set_ISBN("");
            deleteRecord.set_year("");
            deleteRecord.set_edition("");
            break;
        }
        temp = temp->next;  
    }

}

// Prompts user for yes or no and returns Y or N
char Library::prompt_yes_no() {
    string choice;
    char response;
    cout << "Enter your choice 'yes' or 'no': ";
    cin >> choice;
    if (choice == "yes" || choice == "Yes" || choice == "Y" || choice =="y") {
        response = 'Y';
    } else {
        response = 'N';
    }
    return response;
}

// Given a vector of menu options returns index of choice
int Library::prompt_menu(std::vector<std::string>vect) {
    cout << "Please select an option" << endl;
    for (int i = 0; i < vect.size(); i++) {
        cout << i + 1 << ". " << vect[i] << endl;
    }
    cout << "> ";
    string response;
    cin >> response;
    char index = response[0];
    return index - 49;
}

// prompts user for new record
Record Library::prompt_record() {
    Record rec;
    cout << "Enter the data for the book (Title, Author, ISBN, Year, Edition each on their own line): ";
    cin >> rec;
    return rec;
}

// prompt for a valid title
std::string Library::prompt_title() {
    string title;
    cout << "Enter the title of the book: ";
    getline(cin, title);
    return title;
}

// prompt for a valid string
std::string Library::prompt_string(std::string prompt) {
    string String;
    cout << "Enter a valid String: ";
    getline(cin, String);
    return String;
}