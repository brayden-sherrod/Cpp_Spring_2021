/**
* DO NOT MODIFY THIS FILE
* DO NOT UPLOAD THIS FILE TO MIMIR
* THIS FILE CALLS TESTING FUNCTIONS OF Jeans
*/
#include <iostream>
#include <fstream>
#include <sstream>
#include "Stress_ball.h"
#include "Collection.h"
void test_stress_balls();