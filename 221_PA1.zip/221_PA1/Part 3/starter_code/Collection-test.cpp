/**
* DO NOT MODIFY THIS FILE
* DO NOT UPLOAD THIS FILE TO MIMIR
* THIS FILE CALLS TESTING FUNCTIONS OF Stress_ball and Jeans
*/
#include <iostream>
#include "Stress_ball_test.h"
#include "Jeans_test.h"
using namespace std;
int main() {   
    test_stress_balls();
    test_jeans();
    return 0; 
} 