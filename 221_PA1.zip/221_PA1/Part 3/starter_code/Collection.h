/**
 * There is no Collection.cpp for this assignment.
 * Move all the functions from Collection.cpp to this file except Operator>> 
 * Covert the Collection class to a templated form. (Obj should be replaced with typename "Obj".
 *   Obj_colors and Obj_sizes should be replaced with typename "F2").
 * This file has to be uploaded to mimir.
 */

#ifndef Collection_H
#define Collection_H
#include "Stress_ball.h"
#include "Jeans.h"
#include <string>
#include <iostream>

enum class Sort_choice{bubble_sort, insertion_sort, selection_sort};
template<typename Obj,typename F1,typename F2>
class Collection{
    Obj* array;
    int size;
    int capacity;
    // Resize Function
    void resize() {
        if (capacity == 0) {
            capacity = 1;
        }
        capacity *= 2;
        Obj* A = new Obj[capacity];
        for (int i = 0; i < size; i++) {
            A[i] = array[i];
        }
        delete[] array;
        array = A;
        A = nullptr;
    }

    public:
    // Default Constructor
    Collection() {
        size = 0;
        capacity = 0;
        array = nullptr;
    }

    // Constructor with capacity
    Collection(int cap) {
        capacity = cap;
        size = 0;
        array = new Obj[cap];
    }

    // Copy Constructor
    Collection(const Collection& c) {
        size = c.size;
        capacity = c.capacity;
        array = new Obj[capacity];
        for (int i = 0; i < size; i++) {
            array[i] = c.array[i];
        }
    }

    // Copy Assignment
    Collection& operator=(const Collection& c) {
        if (this != &c) {
            size = c.size;
            capacity = c.capacity;
            array = new Obj[capacity];
            for (int i = 0; i < size; i++) {
                array[i] = c.array[i];
            }
        }
        return *this;
    }

    // Destructor
    ~Collection() {
        delete[] array;
        array = nullptr;
        size = 0;
        capacity = 0;
    }

    // Move Constructor
    Collection(Collection&& c) {
        size = c.size;
        c.size = 0;
        capacity = c.capacity;
        c.capacity = 0;
        array = c.array;
        c.array = nullptr;
    }

    // Move Assignment
    Collection& operator=(Collection&& c) {
        array = c.array;
        c.array = nullptr;
        size = c.size;
        c.size = 0;
        capacity = c.capacity;
        c.capacity = 0;
        return *this;
    }

    // Insert_item Function
    void insert_item(const Obj& sb) {
        if (size == capacity) {
            this->resize();
        }
        array[size] = sb;
        size++;
    }

    // Contains Function
    bool contains(const Obj& sb) const {
        for (int i = 0; i < size; i++) {
            if (array[i] == sb) {
                return true;
            }
        }
        return false;
    }

    // Remove Random Stress Ball Function
    Obj remove_any_item() {
        if (size == 0) {
            throw "Empty Collection";
        }
        srand (time(NULL));
        int remove_index = rand() % (size);
        Obj removed_Obj;
        removed_Obj = array[remove_index];
        for (int i = remove_index; i < size -1; i++) {
            array[i] = array[i+1];
        }
        size--;
        return removed_Obj;
    }

    // Remove Stress Ball With Given Color and Size
    void remove_this_item(const Obj& sb) {
        if (size == 0) {
            throw "Empty Collection";
        }
        int remove_index = 0;
        bool remove = false;
        for (int i = 0; i < size; i++) {
            if (array[i] == sb) {
                remove_index = i;
                remove = true;
                break;
            }
        }
        if (remove) {
            for (int i = remove_index; i < size -1; i++) {
                array[i] = array[i+1];
            }
            size--;
        }
    }

    // Make Empty Function
    void make_empty() {
        delete[] array;
        array = nullptr;
        size = 0;
        capacity = 0;
    }

    // Is Empty Function
    bool is_empty() const {
        if (size == 0) {
            return true;
        } else {
            return false;
        }
    }

    // Total Items Function
    int total_items() const {
        return size;
    }

    // Total Items With Given Size
    int total_items(F2 s) const {
        int size_count = 0;
        for (int i = 0; i < size; i++) {
            if (array[i].get_size() == s) {
                size_count++;
            }
        }
        return size_count;
    }

    // Total Items With Given Color
    int total_items(F1 c) const {
        int color_count = 0;
        for (int i = 0; i < size; i++) {
            if (array[i].get_color() == c) {
                color_count++;
            }
        }
        return color_count;
    }

    // Print Stress Balls
    void print_items() const {
        for (int i = 0; i < size; i++) {
            cout << array[i] << endl;
        }
    }

    // Overloaded operator[]
    Obj& operator[](int i) {
        return array[i];
    }

    // Overloaded const operator[]
    const Obj& operator[](int i) const {
        return array[i];
    }

    // Swap Function
    void swap(Collection& c1, Collection& c2) {
        Collection temp;
        temp = std::move(c1);
        c1 = std::move(c2);
        c2 = std::move(temp);
    }
};


// Sort_by_size function
template<typename Obj, typename F1, typename F2>
void sort_by_size(Collection<Obj, F1, F2>& c, Sort_choice sort) {
    switch(sort) {
        case Sort_choice::bubble_sort : { // Bubble
            for (int i = 0; i < c.total_items() - 1; i++) {
                for (int j = 0; j < c.total_items() -i - 1; j++) {
                    if (c[j].get_size() > c[j+1].get_size()) {
                        Obj temp = c[j];
                        c[j] = c[j+1];
                        c[j+1] = temp;
                    }
                }
            }
            break;
        }
        case Sort_choice::insertion_sort : { // Insertion
            Obj key;
            int j;
            for (int i = 1; i < c.total_items(); i++) {
                key = c[i];
                j = i-1;
                while (j >= 0 && c[j].get_size() > key.get_size()) {
                    c[j +1] = c[j];
                    j--;
                }
                c[j +1] = key;
            }
            break;
        }
        case Sort_choice::selection_sort : { // Selection
            int min_index;
            for (int i = 0; i < c.total_items()-1; i++) {
                min_index = i;
                for (int j = i+1; j < c.total_items(); j++) {
                    if (c[j].get_size() < c[min_index].get_size()) {
                        min_index = j;
                        Obj temp = c[min_index];
                        c[min_index] = c[i];
                        c[i] = temp;
                    }
                }
            }
            break;
        }
    }
}


// ostream << overloaded operator
template<typename Obj, typename F1, typename F2>
ostream& operator<<(ostream& os, const Collection<Obj, F1, F2>& c) {
    for (int i = 0; i < c.total_items(); i++) {
        os << c[i] << endl;
    }
    return os;
}

// Union Function
template<typename Obj, typename F1, typename F2>
Collection<Obj, F1, F2> make_union(const Collection<Obj, F1, F2>& c1, const Collection<Obj, F1, F2>& c2) {
    Collection<Obj, F1, F2> c3(c1.total_items() + c2.total_items());
    for (int i = 0; i < c1.total_items(); i++) {
        c3.insert_item(c1[i]);
    }
    for (int i = 0; i < c2.total_items(); i++) {
        c3.insert_item(c2[i]);
    }
    return c3;
}

//your code...
//Templated class collection
//Methods from Collection.cpp
#endif