/**
 * In this file, implement the methods from Jeans.h. The implementation is identical to Jeans
 * This file needs to be uploaded to Mimir
 */ 
#include "Jeans.h"

using namespace std;
// Default Constructor
Jeans::Jeans() {
srand ( time(NULL));
color = Jeans_colors(rand() % 4);
size = Jeans_sizes(rand() % 4);
}

// Parametrized Constructor
Jeans::Jeans(Jeans_colors c, Jeans_sizes s) : color(c), size(s){};

// Get Color
Jeans_colors Jeans::get_color() const {
    return color;
}

// Get Size
Jeans_sizes Jeans::get_size() const{
    return size;
}

bool Jeans::operator==(const Jeans& sb)  {
    if (sb.get_color() == this->color & sb.get_size() == this->size) {
        return true;
    } else {
        return false;
    }
}

ostream& operator<<(ostream& o, const Jeans& sb) {
    string color_out;
    string size_out;
    switch(sb.get_color()) {
        case Jeans_colors::white:
            color_out = "white";
            break;
        case Jeans_colors::black:
            color_out = "black";
            break;
        case Jeans_colors::blue:
            color_out = "blue";
            break;
        case Jeans_colors::grey:
            color_out = "grey";
            break;
    }
    switch(sb.get_size()) {
        case Jeans_sizes::small:
            size_out = "small";
            break;
        case Jeans_sizes::medium:
            size_out = "medium";
            break;
        case Jeans_sizes::large:
            size_out = "large";
            break;
        case Jeans_sizes::xlarge:
            size_out = "xlarge";
            break;
    }
    
    o << "(" << color_out << ", " << size_out << ")";
    return o;
}
