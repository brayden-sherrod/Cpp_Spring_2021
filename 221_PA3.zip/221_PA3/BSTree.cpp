#include "BSTree.h"

#include <iostream>
#include <queue>
#include <deque>
using namespace std;

///////////////////////////////////
// Already Implemented Functions //
///////////////////////////////////

// These functions are already implemented for you. Scroll below to
// see the functions that you have to implement 


// constructors
BSTree::BSTree() : size(0), root(nullptr) {}

// input / output operators
ostream& operator<<(ostream& out, BSTree& tree)
{
    tree.print_level_by_level(out);
    return out;
}

ostream& operator<<(ostream& out, Node& node)
{
    return out << node.value << "[" << node.search_time << "]";
}

istream& operator>>(istream& in, BSTree& tree)
{
    /*
      take input from the in stream, and build your tree
      input will look like
      4 
      2 
      6 
      1 
      3 
      5 
      7
    */
    int next;
    while(in >> next) {
        tree.insert(next);
    }
    return in;
}

// Example recursive function
// If you try to use it without care, you will get a memory leak.
void BSTree::copy_helper(Node*& newNode, const Node* sourceNode) {
    //Don't copy if the node is nullptr
    if(sourceNode == nullptr)
        return;

    //Change the new node to a copy of sourceNode
    newNode = new Node(sourceNode->value);
    //Copy over the search cost
    newNode->search_time = sourceNode->search_time;

    //Copy left subtree
    if (sourceNode->left != nullptr)
        copy_helper(newNode->left, sourceNode->left);
    //Copy right subtree
    if(sourceNode->right != nullptr)
        copy_helper(newNode->right, sourceNode->right);
}

// recursive function
int BSTree::get_total_search_time(Node* node)
{
  if (node != nullptr) {
    return node->search_time + get_total_search_time(node->left) + get_total_search_time(node->right);
  }
  return 0;
}

// implemented
float BSTree::get_average_search_time()
{
  int total_search_time = get_total_search_time(root);
  if(total_search_time == 0)
    return -1;
	
  return ((float)total_search_time)/size;
}


///////////////////////////////////
//     Functions to Implement    //
///////////////////////////////////

// These are the functions you should implement
// Feel free to call the functions above or create new helper functions

// copy constructor
BSTree::BSTree(const BSTree& other)
{
  size = other.size;
  root = other.root;
  copy_helper(root, other.root);
}

// move constructor
BSTree::BSTree(BSTree&& other)
{
  root = other.root;
  size = other.size;
  other.root = nullptr;
  other.size = 0;
}

//copy assignment
BSTree& BSTree::operator=(const BSTree& other)
{
  if (this == &other) {
    return *this;
  }
  if (root != nullptr) {
    clear(root);
    root = nullptr;
    size = 0;
  }
  size = other.size;
  root = other.root;
  copy_helper(root, other.root);
  return *this;
}

// move assignment
BSTree& BSTree::operator=(BSTree&& other)
{
  if (this == &other) {
    return *this;
  }
  if (root != nullptr) {
    clear(root);
    root = nullptr;
    size = 0;
  }
  root = other.root;
  size = other.size;
  other.root = nullptr;
  other.size = 0;
  return *this;
}

// destructor
BSTree::~BSTree()
{
  clear(root);
  root = nullptr;
  size = 0;

    // Make sure to call delete on every node of the tree
    // You can use a recursive helper function to do this
}

void BSTree::clear(Node* node) {
  if (node != nullptr) {
    clear(node->left);
    node->left = nullptr;
    clear(node->right);
    node->right = nullptr;
    delete node;
  }
}

Node* BSTree::insert(int obj)
{
  Node* spot;
  Node* newNode = new Node(obj);
  if (root == nullptr) {
    root = newNode;
    newNode->search_time = 1;
    this->size = 1;
    return root;
  } else {
    spot = find_and_fill_spot(root, newNode, 1);
  }
  this->size++;
  return spot;
}

Node* BSTree::find_and_fill_spot(Node* curr_root, Node* insert_Node, int time) {
  if (curr_root == nullptr) {
    insert_Node->search_time = time;
    return insert_Node;
  } 
  if (curr_root->value < insert_Node->value) {
    curr_root->right = find_and_fill_spot(curr_root->right, insert_Node, time +1);
  } else {
    curr_root->left = find_and_fill_spot(curr_root->left, insert_Node, time + 1);
  }
  if (time == 1) {
    return insert_Node;
  } else {
    return curr_root;
  }
  
}

Node* BSTree::search(int obj)
{
  Node* spot = find_node(root, obj);
  return spot;
    /* recursively search down the tree to find the node that contains obj
    if you don't find anything return nullptr */
}

Node* BSTree::find_node(Node* curr_node, int obj) {
  if (curr_node == nullptr) {
    return nullptr;
  }
  if (curr_node->value == obj) {
    return curr_node;
  }
  if (obj > curr_node->value) {
    find_node(curr_node->right, obj);
  } else {
    find_node(curr_node->left, obj);
  }
}

void BSTree::update_search_times()
{
  recursive_update(root, 1);
    /* do a BFS or DFS of your tree and update the search times of all nodes at once
      The root has a search time of 1, and each child is 1 more than its parent */
}

void BSTree::recursive_update(Node* curr_node, int time) {
  curr_node->search_time = time;
  if (curr_node->right != nullptr) {
    recursive_update(curr_node->right, time + 1);
  }
  if (curr_node->left != nullptr) {
    recursive_update(curr_node->left, time +1);
  }
}

void BSTree::inorder(ostream& out)
{
  recursive_inorder(out, root);
    /* print your nodes in infix order
    If our tree looks like this:

       4
     2   6
    1 3 5 7

    It should output:
    1[3] 2[2] 3[3] 4[1] 5[3] 6[2] 7[3]
    You can use the << operator to print the nodes in the format shown */
}

void BSTree::recursive_inorder(ostream& out, Node* curr_node) {
  if (curr_node->left != nullptr) {
    recursive_inorder(out, curr_node->left);
  }
  out << *curr_node;
  if (curr_node->right != nullptr) {
    recursive_inorder(out, curr_node->right);
  }
}

void BSTree::print_level_by_level(ostream& out)
{
  queue<Node*> q;
  q.push(root);
  int elementsInLevel = 1;
  bool nonNullChild = false;
  while (elementsInLevel > 0) {
    Node* node = q.front();
    q.pop();
    elementsInLevel--;
    if (node != nullptr) {
      out << *node << " ";
      q.push(node->left);
      q.push(node->right);
      if (node->left != nullptr || node->right != nullptr) {
        nonNullChild = true;
      }
    } else {
      out << "X ";
      q.push(nullptr);
      q.push(nullptr);
    }
    if (elementsInLevel == 0) {
      out << endl;
      if (nonNullChild == true) {
        nonNullChild = false;
        elementsInLevel = q.size();
      }
    }
  }




    /* Print the tree using a BFS so that each level contains the values for a level of the tree.
    Use X to mark empty positions. 
    
      if our tree looks like this:

       4
     2   6
    1   5 7
           9

    it should output:

    4[1]
    2[2] 6[2]
    1[3] X 5[3] 7[3]
    X X X X X X X 9[4]

    it might be helpful to do this part with the std::queue data structure.
    Hint: the Nth level contains 2^(N-1) nodes (with a value or with an X). Watch out
    for nodes like the left child of 6 above, and print the descendents of an empty
    node as also empty
    You can use the << operator to print nodes in the format shown */
}
