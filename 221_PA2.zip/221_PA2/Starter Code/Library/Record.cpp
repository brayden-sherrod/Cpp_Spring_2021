//implementation of record class

#include "Record.h"

// getters
string Record::get_title() const {
    return title;
}
string Record::get_author() const {
    return author;
}
string Record::get_ISBN() const {
    return ISBN;
}
string Record::get_year() const {
    return year;
}
string Record::get_edition() const {
    return edition;
}

// setters
void Record::set_title(string _title) {
    title = _title;
}
void Record::set_author(string _author) {
    author = _author;
}
void Record::set_ISBN(string _ISBN) {
    ISBN = _ISBN;
}
void Record::set_year(string _year) {
    year = _year;
}
void Record::set_edition(string _edition) {
    edition = _edition;
}
// input operator
std::istream& operator>>(std::istream& is, Record& rec) {
    string title, author, ISBN, year, edition, blankSpace;
    getline(is, blankSpace);
    getline(is, title);
    getline(is, author, '\n');
    getline(is, ISBN, '\n');
    getline(is, year, '\n');
    getline(is, edition, '\n');
    rec.set_title(title);
    rec.set_author(author);
    rec.set_ISBN(ISBN);
    rec.set_year(year);
    rec.set_edition(edition);
    return is;
}

// output operator
std::ostream& operator<<(std::ostream& os, Record& rec) {
    os << rec.get_title() << endl;
    os << rec.get_author() << endl;
    os << rec.get_ISBN() << endl;
    os << rec.get_year() << endl;
    os << rec.get_edition() << endl;
    return os;
}

// equality operator
bool operator==(const Record& r1, const Record& r2) {
    if (r1.get_title() == r2.get_title() && 
    r1.get_author() == r2.get_author() && 
    r1.get_ISBN() == r2.get_ISBN()) {
        return true;
    } else {
        return false;
    }
    
}