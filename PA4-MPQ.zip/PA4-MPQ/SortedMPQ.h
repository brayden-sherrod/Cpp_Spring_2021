#ifndef SORTEDMPQ_H
#define SORTEDMPQ_H

#include <iostream>
#include <stdexcept>
#include <list>
#include "MPQ.h"



/*
 * Minimum Priority Queue based on a linked list
 */
template <typename T>
class SortedMPQ: MPQ<T> {
   std::list<T> queue;
   // Implement the four funtions (insert, is_empty, min, remove_min) from MPQ.h
   // To hold the elements use std::list
   // For remove_min() and min() throw exception if the SortedMPQ is empty. Mimir already has a try/catch block so don't use try/catch block here.
   public:
   T remove_min() {
      if (this->is_empty()) {
         throw EmptyQueue();
      } else {
         T removeItem = queue.front();
         queue.pop_front();
         return removeItem;
      }
   }
   T min() {
      if (this->is_empty()) {
         throw EmptyQueue();
      } else {
         T removeItem = queue.front();
         return removeItem;
      }
   }
   bool is_empty() {
      return queue.empty();
   }
   void insert(const T& data) {
      if (this->is_empty()) {
         queue.push_front(data);
      } else {
         bool inserted = false;
         typename std::list<T>::iterator it = queue.begin();
         for (; it != queue.end(); it++) {
            if (data < *it && !inserted) {
               queue.insert(it, data);
               inserted = true;
            }
         }
         if (!inserted) {
            queue.push_back(data);
         }
      }
   }
};

#endif