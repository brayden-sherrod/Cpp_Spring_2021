#include <iostream>

using namespace std;

int main(){
    enum class Candy {snicker,kitkat, twix};
    // values should be {0,1,2}
    Candy c1 = Candy::snicker;
    Candy c2 = Candy::kitkat;
    Candy c3 = Candy::twix;
    cout << "Candy test" << endl;
    cout << boolalpha << (Candy::snicker==c1) << endl;
    cout << boolalpha << (c1==c1) << endl;
    cout << boolalpha << (c1==c2) << endl;
    cout << boolalpha << (c1==c3) << endl;

    cout << "\nCandy to number test" << endl;
    int k = (int)Candy::kitkat;
    cout << k << endl;
    cout << boolalpha << (k==1) << endl;
    cout << boolalpha << (k==(int)Candy::kitkat) << endl;

    enum class Fruit {Blueberry, Strawberry = 5, Apple = 7};
    // values should be {0,5,7}
    Fruit f1 = Fruit::Blueberry;
    Fruit f2 = Fruit::Strawberry;
    Fruit f3 = Fruit::Apple;

    cout << "\nFruit test" << endl;
    cout << boolalpha << (Fruit::Blueberry==f1) << endl;
    cout << boolalpha << (f1==f1) << endl;
    cout << boolalpha << (f1==f2) << endl;
    cout << boolalpha << (f1==f3) << endl;

    int b = (int)Fruit::Apple;
    cout << "\nFruit to number test" << endl;
    cout << b << endl;
    cout << boolalpha << (b==7) << endl;
    cout << boolalpha << (b==(int)Fruit::Apple) << endl;

//    if (f1==c1)
//        cout << "Blueberry is the same as a snicker" << endl;
    int Blueberry = 0;
    return 0;
}
