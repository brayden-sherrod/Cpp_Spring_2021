#include "Stress_ball.h"
#include <iostream>
#include <string>


using namespace std;

//enum class Stress_ball_colors {red, blue, yellow, green};
//enum class Stress_ball_sizes {small, medium, large};

 

// Default Constructor
Stress_ball::Stress_ball() {
srand ( time(NULL));
color = Stress_ball_colors(rand() % 4);
size = Stress_ball_sizes(rand() % 3);
}

// Parametrized Constructor
Stress_ball::Stress_ball(Stress_ball_colors c, Stress_ball_sizes s) : color(c), size(s){};

// Get Color
Stress_ball_colors Stress_ball::get_color() const {
    return color;
}

// Get Size
Stress_ball_sizes Stress_ball::get_size() const{
    return size;
}

bool Stress_ball::operator==(const Stress_ball& sb)  {
    if (sb.get_color() == this->color & sb.get_size() == this->size) {
        return true;
    } else {
        return false;
    }
}

ostream& operator<<(ostream& o, const Stress_ball& sb) {
    string color_out;
    string size_out;
    switch(sb.get_color()) {
        case Stress_ball_colors::red:
            color_out = "red";
            break;
        case Stress_ball_colors::blue:
            color_out = "blue";
            break;
        case Stress_ball_colors::yellow:
            color_out = "yellow";
            break;
        case Stress_ball_colors::green:
            color_out = "green";
            break;
    }
    switch(sb.get_size()) {
        case Stress_ball_sizes::small:
            size_out = "small";
            break;
        case Stress_ball_sizes::medium:
            size_out = "medium";
            break;
        case Stress_ball_sizes::large:
            size_out = "large";
            break;
    }
    
    o << "(" << color_out << ", " << size_out << ")";
    return o;
}




