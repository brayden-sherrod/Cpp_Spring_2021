#include "Collection.h"
#include "Stress_ball.h"
#include <string>
#include <stdexcept>
using namespace std;

// Default Constructor
Collection::Collection() {
    size = 0;
    capacity = 0;
    array = nullptr;
}

// Constructor with capacity
Collection::Collection(int cap) {
    capacity = cap;
    size = 0;
    array = new Stress_ball[cap];
}

// Copy Constructor
Collection::Collection(const Collection& c) {
    size = c.size;
    capacity = c.capacity;
    array = new Stress_ball[capacity];
    for (int i = 0; i < size; i++) {
        array[i] = c.array[i];
    }
}

// Copy Assignment
Collection& Collection::operator=(const Collection& c) {
    if (this != &c) {
        size = c.size;
        capacity = c.capacity;
        array = new Stress_ball[capacity];
        for (int i = 0; i < size; i++) {
            array[i] = c.array[i];
        }
    }
    return *this;
}

// Destructor
Collection::~Collection() {
    delete[] array;
    array = nullptr;
    size = 0;
    capacity = 0;
}

// Move Constructor
Collection::Collection(Collection&& c) {
    size = c.size;
    c.size = 0;
    capacity = c.capacity;
    c.capacity = 0;
    array = c.array;
    c.array = nullptr;
}

// Move Assignment
Collection& Collection::operator=(Collection&& c) {
    array = c.array;
    c.array = nullptr;
    size = c.size;
    c.size = 0;
    capacity = c.capacity;
    c.capacity = 0;
    return *this;
}

// Resize Function
void Collection::resize() {
    if (capacity == 0) {
        capacity = 1;
    }
    capacity *= 2;
    Stress_ball* A = new Stress_ball[capacity];
    for (int i = 0; i < size; i++) {
        A[i] = array[i];
    }
    delete[] array;
    array = A;
    A = nullptr;
}

// Insert_item Function
void Collection::insert_item(const Stress_ball& sb) {
    if (size == capacity) {
        this->resize();
    }
    array[size] = sb;
    size++;
}

// Contains Function
bool Collection::contains(const Stress_ball& sb) const {
    for (int i = 0; i < size; i++) {
        if (array[i] == sb) {
            return true;
        }
    }
    return false;
}

// Remove Random Stress Ball Function
Stress_ball Collection::remove_any_item() {
    if (size == 0) {
        throw "Empty Collection";
    }
    srand (time(NULL));
    int remove_index = rand() % (size);
    Stress_ball removed_stress_ball;
    removed_stress_ball = array[remove_index];
    for (int i = remove_index; i < size -1; i++) {
        array[i] = array[i+1];
    }
    size--;
    return removed_stress_ball;
}

// Remove Stress Ball With Given Color and Size
void Collection::remove_this_item(const Stress_ball& sb) {
    if (size == 0) {
        throw "Empty Collection";
    }
    int remove_index = 0;
    bool remove = false;
    for (int i = 0; i < size; i++) {
        if (array[i] == sb) {
            remove_index = i;
            remove = true;
            break;
        }
    }
    if (remove) {
        for (int i = remove_index; i < size -1; i++) {
            array[i] = array[i+1];
        }
        size--;
    }
}

// Make Empty Function
void Collection::make_empty() {
    delete[] array;
    array = nullptr;
    size = 0;
    capacity = 0;
}

// Is Empty Function
bool Collection::is_empty() const {
    if (size == 0) {
        return true;
    } else {
        return false;
    }
}

// Total Items Function
int Collection::total_items() const {
    return size;
}

// Total Items With Given Size
int Collection::total_items(Stress_ball_sizes s) const {
    int size_count = 0;
    for (int i = 0; i < size; i++) {
        if (array[i].get_size() == s) {
            size_count++;
        }
    }
    return size_count;
}

// Total Items With Given Color
int Collection::total_items(Stress_ball_colors c) const {
    int color_count = 0;
    for (int i = 0; i < size; i++) {
        if (array[i].get_color() == c) {
            color_count++;
        }
    }
    return color_count;
}

// Print Stress Balls
void Collection::print_items() const {
    for (int i = 0; i < size; i++) {
        cout << array[i] << endl;
    }
}

// Overloaded operator[]
Stress_ball& Collection::operator[](int i) {
    return array[i];
}

// Overloaded const operator[]
const Stress_ball& Collection::operator[](int i) const {
    return array[i];
}

// istream >> overloaded operator
istream& operator>>(istream& is, Collection& c) {
    Stress_ball_colors color_in;
    Stress_ball_sizes size_in;
    string color;
    string size;
    while (is >> color >> size) {
        if (color == "red") {
        color_in = Stress_ball_colors::red;
        }
        if (color == "blue") {
            color_in = Stress_ball_colors::blue;
        }
        if (color == "green") {
            color_in = Stress_ball_colors::green;
        }
        if (color == "yellow") {
            color_in = Stress_ball_colors::yellow;
        }
        if (size == "small") {
            size_in = Stress_ball_sizes::small;
        }
        if (size == "medium") {
            size_in = Stress_ball_sizes::medium;
        }
        if (size == "large") {
            size_in = Stress_ball_sizes::large;
        }
        c.insert_item(Stress_ball(color_in,size_in));
    }
    return is;
}

// ostream << overloaded operator
ostream& operator<<(ostream& os, const Collection& c) {
    for (int i = 0; i < c.total_items(); i++) {
        os << c[i] << endl;
    }
    return os;
}

// Union Function
Collection make_union(const Collection& c1, const Collection& c2) {
    Collection c3(c1.total_items() + c2.total_items());
    for (int i = 0; i < c1.total_items(); i++) {
        c3.insert_item(c1[i]);
    }
    for (int i = 0; i < c2.total_items(); i++) {
        c3.insert_item(c2[i]);
    }
    // Testing
    /*
    for (int i = 0; i < c1.total_items(); i++) {
        if (c3.contains(c1[i])) {
            cout << "c3 does contain " << c1[i] << endl;
        }
    }
    for (int i = 0; i < c2.total_items(); i++) {
        if (c3.contains(c2[i])) {
            cout << "c3 does contain " << c2[i] << endl;
        }
    }
    */
    return c3;
}

// Swap Function
void swap(Collection& c1, Collection& c2) {
    Collection temp;
    temp = std::move(c1);
    c1 = std::move(c2);
    c2 = std::move(temp);
}

// Sort_by_size function
void sort_by_size(Collection& c, Sort_choice sort) {
    switch(sort) {
        case Sort_choice::bubble_sort : { // Bubble
            for (int i = 0; i < c.total_items() - 1; i++) {
                for (int j = 0; j < c.total_items() -i - 1; j++) {
                    if (c[j].get_size() > c[j+1].get_size()) {
                        Stress_ball temp = c[j];
                        c[j] = c[j+1];
                        c[j+1] = temp;
                    }
                }
            }
            break;
        }
        case Sort_choice::insertion_sort : { // Insertion
            Stress_ball key;
            int j;
            for (int i = 1; i < c.total_items(); i++) {
                key = c[i];
                j = i-1;
                while (j >= 0 && c[j].get_size() > key.get_size()) {
                    c[j +1] = c[j];
                    j--;
                }
                c[j +1] = key;
            }
            break;
        }
        case Sort_choice::selection_sort : { // Selection
            int min_index;
            for (int i = 0; i < c.total_items()-1; i++) {
                min_index = i;
                for (int j = i+1; j < c.total_items(); j++) {
                    if (c[j].get_size() < c[min_index].get_size()) {
                        min_index = j;
                        Stress_ball temp = c[min_index];
                        c[min_index] = c[i];
                        c[i] = temp;
                    }
                }
            }
            break;
        }
    }
}