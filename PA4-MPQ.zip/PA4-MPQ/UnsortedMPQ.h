#ifndef UNSORTEDMPQ_H
#define UNSORTEDMPQ_H

#include <stdexcept>
#include <vector>
#include "MPQ.h"
#include <exception>


/**
 * Minimum Priority Queue based on a vector
 */
template <typename T>
class UnsortedMPQ: MPQ<T> {
   std::vector<T> queue;
   // Implement the four funtions (insert, is_empty, min, remove_min) from MPQ.h
   // To hold the elements use std::vector
   // For remove_min() and min() just throw exception if the UnsortedMPQ is empty. Mimir already has a try/catch block so don't use try/catch block here.
   public:
   T remove_min() {
      if (this->is_empty()) {
         throw EmptyQueue();
      } else {
         T minValue = queue[0];
         int minIndex = 0;
         for (int i = 0; i < queue.size(); i++) {
            if (queue[i] < minValue) {
               minValue = queue[i];
               minIndex = i;
            }
         }
         queue.erase(queue.begin() + minIndex);
         return minValue;
      }
   }
   T min() {
      if (this->is_empty()) {
         throw EmptyQueue();
      } else {
         T minValue = queue[0];
         for (int i = 0; i < queue.size(); i++) {
            if (queue[i] < minValue) {
               minValue = queue[i];
            }
         }
         return minValue;
      }
   }
   bool is_empty() {
      return queue.empty();
   }
   void insert(const T& data) {
      queue.push_back(data);
   }
};

#endif